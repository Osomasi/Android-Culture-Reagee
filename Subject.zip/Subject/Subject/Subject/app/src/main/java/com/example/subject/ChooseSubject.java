package com.example.subject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;

public class ChooseSubject extends AppCompatActivity {
    private RadioButton r1;
    private RadioButton r2;
    private RadioButton r3;
    private RadioButton r4;
    private Button confirm;
    private Button back;
    private String sem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_subject);
        setTitle("Choose your subject");
        r1 = (RadioButton)findViewById(R.id.Subject1);
        r2 = (RadioButton)findViewById(R.id.Subject2);
        r3 = (RadioButton)findViewById(R.id.Subject3);
        r4 = (RadioButton)findViewById(R.id.Subject4);
        confirm = (Button)findViewById(R.id.ConfirmSubject);
        back = (Button)findViewById(R.id.ReturnSubject);
        r1.setChecked(true);
        Intent intent = getIntent();
        sem = "1";
        sem = intent.getStringExtra("semester");
        if(sem.compareTo("1") == 0)
        {
            r1.setText("subject11");
            r2.setText("subject12");
            r3.setText("subject13");
            r4.setText("subject14");
        }
        else if(sem.compareTo("2") == 0)
        {
            r1.setText("subject21");
            r2.setText("subject22");
            r3.setText("subject23");
            r4.setText("subject24");
        }
        else if(sem.compareTo("3") == 0)
        {
            r1.setText("subject31");
            r2.setText("subject32");
            r3.setText("subject33");
            r4.setText("subject34");
        }

        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = "1";
                if(r1.isChecked())
                {
                    if(sem.compareTo("1") == 0)
                        s = "11";
                    else if(sem.compareTo("2") == 0)
                        s = "21";
                    else if(sem.compareTo("3") == 0)
                        s = "31";
                }
                else if(r2.isChecked())
                {
                    if(sem.compareTo("1") == 0)
                        s = "12";
                    else if(sem.compareTo("2") == 0)
                        s = "22";
                    else if(sem.compareTo("3") == 0)
                        s = "32";
                }
                else if(r3.isChecked())
                {
                    if(sem.compareTo("1") == 0)
                        s = "13";
                    else if(sem.compareTo("2") == 0)
                        s = "23";
                    else if(sem.compareTo("3") == 0)
                        s = "33";
                }
                else if(r4.isChecked())
                {
                    if(sem.compareTo("1") == 0)
                        s = "14";
                    else if(sem.compareTo("2") == 0)
                        s = "24";
                    else if(sem.compareTo("3") == 0)
                        s = "34";
                }
                Intent intent = new Intent();
                intent.putExtra("semester",sem);
                intent.putExtra("subject",s);
                intent.setClass(ChooseSubject.this,GradeDetail.class);
                startActivity(intent);
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(ChooseSubject.this,ChooseSemester.class);
                startActivity(intent);
            }
        });
    }
}
